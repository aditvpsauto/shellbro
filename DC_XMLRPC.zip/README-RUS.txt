2.12 [10 macros] April 2021
Макросы которые софт поддерживает на данный момент!

Bypass WORDFENCE!

[WPLOGIN] - макрос на узнавание логина админа | например - логин админа mike90 то и пороль подставит такой же
[DDOMAIN] - макрос на домен ссылки | например - https://www.google.com/ = google.com
[DOMAIN] - макрос на имя сайта | например - https://www.google.com/ = google
[UPPERALL] - переводит все буквы в верхний регистор | например - admin = ADMIN
[LOWERALL] - переводит все буквы в нижний регистор | например - ADMIN = admin
[UPPERONE] - переводит первую букву в верхний регистор | например - admin = Admin
[LOWERONE] - переводит первую букву в нижний регистор | например - ADMIN = aDMIN
[UPPERLOGIN] - макрос который подставляет логин админа перед поролем и делает первую букву в верхний регистр
[AZDOMAIN] - удаляет из домена все символы, кроме букв и цифр
[REVERSE] - реверс - admin = nimda

OpenSSL v1.0.2u    Precompiled Binaries for Win64

Add ssl dll for x64

